# tastebuds-ui
Progressive web app for food delivery
