var dashboard = angular.module('dashboard', []);

dashboard.controller('AppController', ['$scope', '$http', function ($scope, $http) {
	console.log('controller placed in position');
	
	$scope.orders = [];
	
	var updateOrders = function () {
		$http.get('/orders').then(function (response) {
			$scope.orders = response.data;
		}, function (data) {
			console.log(data);
		});
		console.log('orders updated');
	}

	var fetchMenu = function () {
		$http.get('/foods').then(function (response) {
			$scope.menu = response.data;
			console.log(response.data);
		}, function (data) {
			console.log(data);
		});
	}

	// update orders every 60 seconds
	updateOrders();
	fetchMenu();
	setInterval(updateOrders, 60 * 1000);


}])